#!/bin/sh
/usr/bin/soffice --accept="socket,host=127.0.0.1,port=8100;urp;"
