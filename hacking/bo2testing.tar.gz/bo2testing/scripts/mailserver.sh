#!/bin/sh
/usr/bin/python -m smtpd -n -c DebuggingServer localhost:25
